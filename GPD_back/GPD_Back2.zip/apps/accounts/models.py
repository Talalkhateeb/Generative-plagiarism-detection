"""
Accounts App — Models
Class Diagram: account (base) → user (sibling) + admin (sibling)

Proxy model pattern:
  - Account  : one DB table, all shared fields (name, id, email, password, status, createdAt, role)
  - User     : proxy of Account, role='user', user-specific methods
  - Admin    : proxy of Account, role='admin', admin-specific methods

This exactly matches the class diagram where user and admin are siblings
that both inherit from account — not one inheriting the other.
"""
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models


# ── Manager for Account (base) ────────────────────────────────────────────────

class AccountManager(BaseUserManager):
    """Base manager — used by Account, User, and Admin."""

    def create_user(self, email, name, password=None, **extra):
        if not email:
            raise ValueError('Email is required')
        email = self.normalize_email(email)
        user  = self.model(email=email, name=name, **extra)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, name, password=None, **extra):
        extra['role']= 'admin'
        extra['is_staff']= True
        extra['is_superuser']= True
        return self.create_user(email, name, password, **extra)


# ── Proxy Manager for User (filters role='user') ──────────────────────────────

class UserManager(AccountManager):
    """Returns only records with role='user'."""
    def get_queryset(self):
        return super().get_queryset().filter(role='user')

    def create_user(self, email, name, password=None, **extra):
        extra['role'] = 'user'
        return super().create_user(email, name, password, **extra)


# ── Proxy Manager for Admin (filters role='admin') ────────────────────────────

class AdminManager(AccountManager):
    """Returns only records with role='admin'."""
    def get_queryset(self):
        return super().get_queryset().filter(role='admin')

    def create_user(self, email, name, password=None, **extra):
        extra['role']     = 'admin'
        extra['is_staff'] = True
        return super().create_user(email, name, password, **extra)


# ── Account (base class — one DB table) ───────────────────────────────────────

class Account(AbstractBaseUser, PermissionsMixin):
    """
    Base class from class diagram: account(-name, -id, -email, -password, -status, -createdAt, -role)
    Methods: +login(password,email), +display_account(), +logout(),
             +edit_info(), +add_account(), +delete_account(id)

    Single DB table — User and Admin are proxy models that share this table.
    """
    ROLE_CHOICES   = [('user', 'User'), ('admin', 'Admin')]
    STATUS_CHOICES = [('active', 'Active'), ('inactive', 'Inactive')]

    name       = models.CharField(max_length=150)
    email      = models.EmailField(unique=True)
    role       = models.CharField(max_length=10, choices=ROLE_CHOICES, default='user')
    status     = models.CharField(max_length=10, choices=STATUS_CHOICES, default='active')
    plan       = models.ForeignKey(
        'plans.Plan', on_delete=models.SET_NULL, null=True, blank=True,
        related_name='subscribers'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    # Email verification (added for OTP flow)
    is_email_verified = models.BooleanField(default=False)

    # Required by Django auth
    is_staff  = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)

    objects = AccountManager()

    USERNAME_FIELD  = 'email'
    REQUIRED_FIELDS = ['name']

    class Meta:
        verbose_name = 'Account'
        ordering     = ['-created_at']

    def __str__(self):
        return f'{self.name} <{self.email}> [{self.role}]'

    def is_admin(self):
        return self.role == 'admin'

    def display_account(self):
        return {'name': self.name, 'email': self.email, 'role': self.role, 'status': self.status}

    def edit_info(self, **kwargs):
        for field, value in kwargs.items():
            setattr(self, field, value)
        self.save()

    def save(self, *args, **kwargs):
      if self.status == 'inactive':
        self.is_active = False
      if self.role == 'admin':
        self.is_staff = True
      super().save(*args, **kwargs)


# ── User (proxy — sibling of Admin, both inherit Account) ─────────────────────

class User(Account):
    """
    Class Diagram: user(-workspace w)
    Methods: +signin(name,password,email), +create_workspace(name),
             +submit_docs(file,w), +download_report(result_id),
             +delete_workspace(id), +choose_plan(id)

    Proxy model: no extra DB table — uses Account table, filters role='user'.
    """
    objects = UserManager()

    class Meta:
        proxy        = True
        verbose_name = 'User'

    def choose_plan(self, plan_id):
        from apps.plans.models import Plan
        self.plan = Plan.objects.get(pk=plan_id)
        self.save(update_fields=['plan'])


# ── Admin (proxy — sibling of User, both inherit Account) ─────────────────────

class Admin(Account):
    """
    Class Diagram: admin(-plan p, -account a)
    Methods: +edit_ustate(id)

    Proxy model: no extra DB table — uses Account table, filters role='admin'.
    """
    objects = AdminManager()

    class Meta:
        proxy        = True
        verbose_name = 'Admin'

    def edit_ustate(self, account_id, new_status):
        Account.objects.filter(pk=account_id).update(status=new_status)


# ── OTP Verification ──────────────────────────────────────────────────────────

class OTPVerification(models.Model):
    """
    Stores 6-digit OTP codes for email verification during signup.
    Expires after 10 minutes. One active OTP per email at a time.
    """
    email      = models.EmailField(db_index=True)
    code       = models.CharField(max_length=6)
    created_at = models.DateTimeField(auto_now_add=True)
    is_used    = models.BooleanField(default=False)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'OTP for {self.email} — used={self.is_used}'

    def is_expired(self):
        from django.utils import timezone
        from datetime import timedelta
        return timezone.now() > self.created_at + timedelta(minutes=10)
